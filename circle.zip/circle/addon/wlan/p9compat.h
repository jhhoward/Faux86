#ifndef _p9compat_h
#define _p9compat_h

#include "p9util.h"
#include "p9arch.h"
#include "p9proc.h"
#include "p9error.h"
#include "p9chan.h"
#include "p9sd.h"
#include "p9ether.h"
#include "p9cmd.h"

#endif
