//
// myclass.cpp
//
#include <template/myclass.h>

CMyClass::CMyClass (void)
{
}

CMyClass::~CMyClass (void)
{
}

// ...
